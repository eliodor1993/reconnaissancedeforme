import cv2
import numpy
import os
from skimage import io
import matplotlib.pyplot as plt
from keras.utils import np_utils
from keras.models import Sequential
from keras.layers import Dense, Dropout, Activation
from PIL import Image
size = 1
fn_haar = 'haarcascade_frontalface_default.xml'
fn_dir = 'att_faces'
fn_dir_test = 'test'
# Part 1: Create LBPH
print('Entrainement...')
haar_cascade = cv2.CascadeClassifier(fn_haar)
# Create a list of images and a list of corresponding names
(images1,images, lables, lables1, names, id) = ([], [], [], [], {}, 0)

# Get the folders containing the training data
for (subdirs, dirs, files) in os.walk(fn_dir):

    # Loop through each folder named after the subject in the photos
    for subdir in dirs:
        names[id] = subdir
        subjectpath = os.path.join(fn_dir, subdir)
        
#Reading each image and assigning respective label 
        # Loop through each photo in the folder
        for filename in os.listdir(subjectpath):

            # Skip non-image formates
            f_name, f_extension = os.path.splitext(filename)
            if(f_extension.lower() not in
                    ['.png','.jpg','.jpeg','.gif','.pgm']):
                print("Sauter "+filename+", mauvais type de fichier")
                continue
            path = subjectpath + '/' + filename
            lable = id
            nbr = f_name
            image = io.imread(path, as_grey=True)
            # Add to training data
            facePoints = haar_cascade.detectMultiScale(image)
            for (x, y, w, h) in facePoints: 
                images.append(cv2.resize(image[y: y + h, x: x + w], (150, 150)).reshape(150*150)) 
                lables.append(nbr)
            #print(facePoints)
            #x = facePoints[0][2]
            #y = facePoints[0][2]
            #x,y = facePoints[0][:2]            
            #cropped = image[y: y + 150, x: x + 150]
            #images.append(cropped)           
        id += 1

nb_classes = id
# Create a Numpy array from the two lists above
(images, lables) = [numpy.array(lis) for lis in [images, lables]]
#images = images.reshape(200, 150*150)
#Splitting Dataset into train and test
lables = np_utils.to_categorical(lables, nb_classes)
images = images.astype('float32')
images /= 255
print(images.shape)
model = Sequential()
model.add(Dense(512,input_shape=(images.shape[1],)))
model.add(Activation('relu'))
model.add(Dropout(0.2))
model.add(Dense(512))
model.add(Activation('relu'))
model.add(Dropout(0.2))
model.add(Dense(nb_classes))
model.add(Activation('softmax'))
model.summary()
model.compile(loss='categorical_crossentropy', optimizer="adam", metrics=['accuracy'])
#model.fit(images, lables, batch_size=64, epochs=50, verbose=1)
model.train_on_batch(images, lables)
# Part 3: test and calculate error
bon=0
tous=0
k=0
# Get the folders containing the training data
for (subdirs1, dirs1, files1) in os.walk(fn_dir_test):

    # Loop through each folder named after the subject in the photos
    for subdir1 in dirs1:
        subjectpath1 = os.path.join(fn_dir_test, subdir1)

        # Loop through each photo in the folder
        for filename1 in os.listdir(subjectpath1):

            # Skip non-image formates
            f_name1, f_extension1 = os.path.splitext(filename1)
            if(f_extension1.lower() not in
                    ['.png','.jpg','.jpeg','.gif','.pgm']):
                print("Sauter "+filename+", mauvais type de fichier")
                continue
            path1 = subjectpath1 + '/' + filename1
            nbr_actual = int(subdir1.replace("s",""))
            #loading the image and converting it to gray scale
            image1 = io.imread(path1, as_grey=True)
            faces1 = haar_cascade.detectMultiScale(image1)
            for (x, y, w, h) in faces1: 
                images1.append( cv2.resize(image1[y: y + h, x: x + w], (150, 150)).reshape(150*150)) 
                lables1.append(nbr_actual)
            #x,y = faces1[0][:2]
            #cropped1 = image1[y: y + 150, x: x + 150]
            #images1.append(cropped1)
            
images1=numpy.array(images1)
print(images1.shape)
#images1 = images1.reshape(200, 150*150)
images1 = images1.astype('float32')
images1 /= 255
for i in images1:
    preds = model.predict(i.reshape(22500))
    print(np.argmax(preds[0]))
    #nbr_predicted=np.argmax(preds[0])
    nbr_actual = int(lables1[k])
    if nbr_actual == nbr_predicted:
        print (nbr_actual," is Correctly Recognized ")
        bon = bon + 1
    else:
        print (nbr_actual,"is Incorrectly Recognized ")
        tous = tous + 1
    k = k +1
print ("Taux de bon classement",bon/tous)
    # Show the image and check for ESC being pressed
#cv2.imshow('Reconnaissance', image1)
#cv2.waitKey(0)
cv2.destroyAllWindows()
